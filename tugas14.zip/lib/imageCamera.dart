import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as path;

class ImageCamera extends StatefulWidget {
  @override
  _ImageCameraState createState() => _ImageCameraState();
}

class _ImageCameraState extends State<ImageCamera> {
  File? _imageCamera;
  final ImagePicker picker = ImagePicker();
  XFile? pickedFile;

  // This function will help you to pick an Image from Camera
  Future<void> _pickImageFromCamera() async {
    if (await Permission.camera.request().isGranted) {
      pickedFile =
          await picker.pickImage(source: ImageSource.camera, imageQuality: 50);

      if (pickedFile != null) {
        setState(() {
          _imageCamera = File(pickedFile!.path);
        });
      } else {
        _showErrorDialog('No image captured');
      }
    } else {
      _showPermissionDeniedDialog();
    }
  }

  Future<void> _saveImageToGallery() async {
    if (await Permission.storage.request().isGranted) {
      if (pickedFile != null) {
        String fileDir = path.dirname(pickedFile!.path);
        var dt = DateTime.now();
        String formattedDate =
            '${dt.year}${_twoDigits(dt.month)}${_twoDigits(dt.day)}_${_twoDigits(dt.hour)}${_twoDigits(dt.minute)}${_twoDigits(dt.second)}';
        String newPath = path.join(fileDir, 'img_cmr_$formattedDate.jpg');

        File image = File(pickedFile!.path).renameSync(newPath);

        if (image.path.isNotEmpty) {
          await GallerySaver.saveImage(image.path, albumName: "Media");
          const snackBar = SnackBar(
            content: Text('Image saved to Gallery'),
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        } else {
          _showErrorDialog('Failed to save the image');
        }
      } else {
        _showErrorDialog('No image to save');
      }
    } else {
      _showPermissionDeniedDialog();
    }
  }

  String _twoDigits(int n) => n.toString().padLeft(2, '0');

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Permission Denied'),
        content: Text(
            'Camera or Storage permission is required to use this feature.'),
        actions: <Widget>[
          TextButton(
            child: Text('OK'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: Text('OK'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                if (_imageCamera != null)
                  Image.file(_imageCamera!)
                else
                  Text(
                    "Click on Pick Image to take picture from Camera",
                    style: TextStyle(fontSize: 18.0),
                  ),
                ElevatedButton(
                  onPressed: () {
                    _pickImageFromCamera();
                  },
                  child: Text("Pick Image From Camera"),
                ),
                if (_imageCamera != null)
                  ElevatedButton(
                    onPressed: () {
                      _saveImageToGallery();
                    },
                    child: Text("Save Image to Gallery"),
                  )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

package com.example.tugas14

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
